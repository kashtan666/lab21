package Task2;

public class test {
    public static void main(String[] args) {
    String[] str = new String[] {"a", "b", "c"};
    Integer[] inte = new Integer[] {1,2,3};
    Xranitel str2 = new Xranitel(str);
    Xranitel inte2 = new Xranitel(inte);
    str2.outArray();
    inte2.outArray();
    }
}
